import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class WelcomeDataService {

  constructor(
     private http:HttpClient
  ) { }

  executeHelloWorldBeanService(){
    return this.http.get<HelloWorldBean>('http://localhost:8080/hello-world-bean');
    //console.log('servicio enlazado');
  }

  executeHelloWorldBeanServiceWithPathVariable(name){

    //let BasicAuthHeaderString = this.createBasicAuthenticationHttpHeaders();

    //let headers = new HttpHeaders({
    //Authorization:BasicAuthHeaderString
    //})

    return this.http.get<HelloWorldBean>(`http://localhost:8080/hello-world/path-variable/${name}`,
      //{headers}
      );
    //console.log('servicio enlazado');
  }


//la misma clave que ha sido creada en la applications de spring boot
  //createBasicAuthenticationHttpHeaders(){
  //  let username ='oscar';
  //  let password ='dummy';
  //  let BasicAuthHeaderString ='Basic'+ window.btoa(username +':'+ password);

  //  return BasicAuthHeaderString;
  //}

}


export class HelloWorldBean{
  constructor(public message:String){}
}